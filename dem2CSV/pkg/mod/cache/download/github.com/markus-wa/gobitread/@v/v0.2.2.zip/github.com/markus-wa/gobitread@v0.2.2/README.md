# gobitread

Provides a bit level reader for go.

[![GoDoc](https://godoc.org/github.com/markus-wa/gobitread?status.svg)](https://godoc.org/github.com/markus-wa/gobitread)
[![Build Status](https://travis-ci.org/markus-wa/gobitread.svg?branch=master)](https://travis-ci.org/markus-wa/gobitread)
[![codecov](https://codecov.io/gh/markus-wa/gobitread/branch/master/graph/badge.svg)](https://codecov.io/gh/markus-wa/gobitread)
[![Go Report](https://goreportcard.com/badge/github.com/markus-wa/gobitread)](https://goreportcard.com/report/github.com/markus-wa/gobitread)
[![License](https://img.shields.io/badge/license-MIT-blue.svg?style=flat)](LICENSE.md)

## Go Get

	go get github.com/markus-wa/gobitread

## Example

	TODO
