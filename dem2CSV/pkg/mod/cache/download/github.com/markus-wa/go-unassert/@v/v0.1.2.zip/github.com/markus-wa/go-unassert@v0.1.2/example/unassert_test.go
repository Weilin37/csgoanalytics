// +build unassert_test

package main

import (
	"testing"
)

func TestExample(t *testing.T) {
	main()
}
