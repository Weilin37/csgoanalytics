// +build !unassert_stderr,!unassert_panic,!unassert_test

package unassert

const enabled = false

var errorHandler ErrorHandler
