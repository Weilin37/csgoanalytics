// +build unassert_stderr

package main

import (
	"testing"
)

func TestExample(t *testing.T) {
	main()
}
