// Package msg contains the generated protobuf demo message code.
//
// Use 'go generate' to generate the code from the .proto files inside the proto sub directory.
// If you're on Windows you'll need to run go generate from CMD, not Bash.
package msg
