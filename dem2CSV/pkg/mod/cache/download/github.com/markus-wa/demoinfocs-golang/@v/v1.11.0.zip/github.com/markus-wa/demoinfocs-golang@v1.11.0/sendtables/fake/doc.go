// Package fake provides basic mocks for IEntity and IProperty.
// See examples/mocking (https://github.com/markus-wa/demoinfocs-golang/tree/master/examples/mocking).
package fake
