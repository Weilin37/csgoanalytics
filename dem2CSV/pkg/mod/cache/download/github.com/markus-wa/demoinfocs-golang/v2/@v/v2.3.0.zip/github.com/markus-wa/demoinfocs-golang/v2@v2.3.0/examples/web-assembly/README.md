# WebAssembly (WASM)

This example shows how to use the library with [WebAssembly](https://webassembly.org/).

Since the build process is somewhat different from the library itself, the example has it's own repository which you can find here:
https://github.com/markus-wa/demoinfocs-wasm
