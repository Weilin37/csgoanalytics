package msg

//go:generate .\generate.bat
