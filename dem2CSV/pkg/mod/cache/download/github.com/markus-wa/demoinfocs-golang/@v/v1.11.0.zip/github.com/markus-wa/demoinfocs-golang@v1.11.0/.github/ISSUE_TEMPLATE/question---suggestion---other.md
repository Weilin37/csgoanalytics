---
name: Question / Suggestion / Other
about: Anything that isn't exactly a bug or feature

---

<!-- If it's a simple question, you may be able to get help over at https://gitter.im/csgodemos/demoinfo-lib -->
