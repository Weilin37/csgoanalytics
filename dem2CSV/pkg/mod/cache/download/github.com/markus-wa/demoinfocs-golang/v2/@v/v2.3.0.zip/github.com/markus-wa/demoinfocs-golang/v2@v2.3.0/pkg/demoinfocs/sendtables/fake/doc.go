// Package fake provides basic mocks for Entity and Property.
// See examples/mocking (https://github.com/markus-wa/demoinfocs-golang/tree/master/examples/mocking).
package fake
